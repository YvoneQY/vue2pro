<template>
  <div>
    <div class="buttons">
      <el-button @click="getCheckedNodes">通过 node 获取</el-button>
      <el-button @click="getCheckedKeys">通过 key 获取</el-button>
      <el-button @click="setCheckedNodes">通过 node 设置</el-button>
      <el-button @click="setCheckedKeys">通过 key 设置</el-button>
      <el-button @click="resetChecked">清空</el-button>
      <el-button @click="leftMove">左移动</el-button>
      <el-button @click="rightMove">右移动</el-button>
    </div>
    <div class="eltransfer">
      <div class="transfer el-left">
        <el-input placeholder="输入关键字进行过滤" v-model="filterText">
        </el-input>
        <el-tree
          :data="fromData"
          show-checkbox
          default-expand-all
          node-key="id"
          ref="fromtree"
          highlight-current
          :filter-node-method="filterNode"
        
          :props="defaultProps"
          @check-change="handleCheckChange"
           @node-click="departmentNodeClick"   
        >
        </el-tree>
      </div>
      <div class="transfer el-right">
        <el-input placeholder="输入关键字进行过滤" v-model="filterRight">
        </el-input>
        <el-tree
          :data="toData"
          show-checkbox
          default-expand-all
          node-key="id"
          ref="totree"
          :default-checked-keys="toCheckDefault"
          highlight-current
          :props="defaultProps"
          :filter-node-method="filterNodeRight"
        >
        </el-tree>
      </div>
    </div>
    <div>
      <div class="transfer el-right">
        <el-input placeholder="输入关键字进行过滤" v-model="filterRight">
        </el-input>
        <el-tree
          :data="deptData"
          show-checkbox
          default-expand-all
          node-key="id"
          ref="totree"
          highlight-current
          :props="defaultProps"
        >
        </el-tree>
      </div>
    </div>
  </div>
</template>

<script>
import { deptList } from "./dept.js";
export default {
  data() {
    return {
      toDefault:[],
      deptData: deptList,
      filterText: "",
      filterRight: "",
      fromData: [
        {
          id: 1,
          label: "一级 1",
          children: [
            {
              id: 4,
              label: "二级 1-1",
              children: [
                {
                  id: 9,
                  label: "三级 1-1-1",
                },
                {
                  id: 10,
                  label: "三级 1-1-2",
                },
              ],
            },
          ],
        },
        {
          id: 2,
          label: "一级 2",
          children: [
            {
              id: 5,
              label: "二级 2-1",
            },
            {
              id: 6,
              label: "二级 2-2",
            },
          ],
        },
        {
          id: 3,
          label: "一级 3",
          children: [
            {
              id: 7,
              label: "二级 3-1",
            },
            {
              id: 8,
              label: "二级 3-2",
            },
          ],
        },
      ],
      toData: [],
      defaultProps: {
        children: "children",
        label: "label",
      },
    };
  },
  watch: {
    filterText(val) {
      this.$refs.fromtree.filter(val);
    },
    filterRight(val) {
      this.$refs.totree.filter(val);
    },
  },
  methods: {

    departmentNodeClick(data){
      console.log('查看---',data)

    },
    handleCheckChange(data, checked, indeterminate) {
      // console.log(data, checked, indeterminate);
    },
    handleNodeClick(data) {
      console.log("选中数据", data);
    },
    handleNodeClick(data) {
      console.log("勾选数据", data);
    },
    leftMove() {},
    rightMove() {},
    filterNodeRight(value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    filterNode(value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    getCheckedNodes() {
      console.log(this.$refs.fromtree.getCheckedNodes());
    },
    getCheckedKeys() {
      console.log(this.$refs.fromtree.getCheckedKeys());
    },
    setCheckedNodes() {
      // this.$refs.fromtree.setCheckedNodes([
      //   {
      //     id: 5,
      //     label: "二级 2-1",
      //   },
      //   {
      //     id: 9,
      //     label: "三级 1-1-1",
      //   },
      // ]);
      console.log(
        "弄得222",
        this.$refs.fromtree.getCheckedKeys(),
        this.$refs.fromtree.getCheckedNodes()
      );
    },
    setCheckedKeys() {
      // this.$refs.fromtree.setCheckedKeys([3]);
      console.log(
        "弄得333",
        this.$refs.fromtree.getCheckedKeys(),
        this.$refs.fromtree.getCheckedNodes(),
        this.$refs.fromtree.getCurrentNode(),
        this.$refs.fromtree.getCurrentKey()
      );
    },
    resetChecked() {
      this.$refs.fromtree.setCheckedKeys([]);
    },
  },
};
</script>

<style scoped>
.eltransfer {
  display: flex;
}
.transfer {
  width: 300px;
  border: 1px solid red;
}
</style>
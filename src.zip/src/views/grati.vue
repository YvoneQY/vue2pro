<template>
  <div class="con-box">
    <div id="map" class="map" />
  </div>
</template>

<script>
import "ol/ol.css";
import olMap from "ol/Map";
import olView from "ol/View";
import ollayerTile from "ol/layer/Tile";
// import olsourceOSM from "ol/source/OSM";
import { get as getProjection, Projection, fromLonLat } from "ol/proj";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import { Point, LineString, Polygon } from "ol/geom";
import XYZ from "ol/source/XYZ";
import { Map, View, Feature, ol } from "ol";
import {
  Circle,
  Fill,
  Stroke,
  Style,
  Text,
  Icon,
  Circle as CircleStyle,
} from "ol/style.js";
import Overlay from "ol/Overlay.js";
import { Image } from "ol/layer.js";
import { OSM, Vector, ImageStatic } from "ol/source";
import {
  defaults as defaultControls,
  FullScreen,
  ZoomToExtent,
  ScaleLine,
} from "ol/control";

import Draw, { createBox, createRegularPolygon } from "ol/interaction/Draw";
import { unByKey } from "ol/Observable";
import { getVectorContext } from "ol/render";
import { easeIn, easeOut } from "ol/easing";
import { Tile as TileLayer } from "ol/layer";
import Graticule from "ol/layer/Graticule";
import TileDebug from "ol/source/TileDebug";

export default {
  data() {
    return {
      map: null,
      view: null,
      opt: {
        img: "",
        imgsize: "",
      },
      source: null,
      duration: 3000,
      tileLayer: null,
      debugLayer: null,
      osmSource: null,
    };
  },
  mounted() {
    this.initgrid();
    this.initmap();
  },

  methods: {
    initgrid() {
      this.osmSource = new OSM();
      this.debugLayer = new TileLayer({
        source: new TileDebug({
          tileGrid: this.osmSource.getTileGrid(),
          projection: this.osmSource.getProjection(),
        }),
        visible: false,
      });
    },

    initmap() {

    //   this.tileLayer = new TileLayer({
    //     source: new OSM({
    //       wrapX: false,
    //     }),
    //   });
      // 定义坐标系
      var projection = new Projection({
        // code: "EPSG:900931", // 用“米”做单位的x/y坐标的投影
        code: "xkcd-image",
        units: "pixels", // 单位：像素
        extent: [0, 0, 1200, 600], // 图片图层四至,分别是静态图片左下角和右上角的基于基站的坐标
      });
      this.view = new olView({
        center: [108, 30],
        projection: projection,
        zoom: 2,
      });
      const gview = new olView({
        // projection: "EPSG:3857",
        center: [300, 500],
        // center: [108, 30],
        // center: fromLonLat([4.8, 47.75]),
        //  projection: projection,
        zoom: 5,
      });

    //   var extent = [
    //     center[0] - (550 * 1000) / 2,
    //     center[1] - (344 * 1000) / 2,
    //     center[0] + (550 * 1000) / 2,
    //     center[1] + (344 * 1000) / 2,
    //   ];
      var imageLayer = new Image({
        source: new ImageStatic({
          //   url: require('../../../public/image/wb.png'),
          url: "https://scpic3.chinaz.net/Files/pic/pic9/201901/bpic10189_s.jpg",
          // imageSize: [1300, 980], // 图片尺寸（px）  [长,宽]
        //   projection: projection,
        //   projection: "EPSG:3857",
          imageExtent: [-450, -300, 900, 500], // // 映射到地图的范围
        }),
      });



      this.source = new VectorSource({ wrapX: false });

      var vector = new VectorLayer({
        source: this.source,
      });

      this.map = new olMap({
        target: "map",
        layers: [
          imageLayer,
        //   this.tileLayer,
          new Graticule({
            strokeStyle: new Stroke({
              color: "rgba(255,120,0,0.9)",
              width: 2,
              lineDash: [0.5, 4],
            }),
            targetSize: 100,
            showLabels: false,
            wrapX: false,
            //   opacity: 0.3,
            Extent: [-100, -100, 100, 100],
          }),

          // vector,
        ],
        // layers: [imageLayer, vector],
        view: gview,
      });
    },
  },
};
</script>

<style scoped>
#map {
  width: 97%;
  margin: 0 auto;
  /* background: rgb(238, 238, 238); */
}
.con-box {
  width: 100%;
  height: 100%;
  border: 1px solid #999999;
}
.map {
  height: 500px;
  border: 1px solid;
}
.icon_but {
  margin: 0 10px;
  padding: 10px;
  border: 1px solid red;
}
.toolbar {
  margin: 10px;
}
.toolbar span {
  display: inline-block;
}

.ol-popup {
  border: 1px solid red;
  font-size: 20px;
  font-weight: bolder;
}
.con-box {
  width: 100%;
  height: calc(100% - 84px);
  border: 1px solid #999999;
}
</style>

<template>
  <div>文件你的我的他的所得内容</div>
</template>

<script>
export default {

}
</script>

<style>

</style>

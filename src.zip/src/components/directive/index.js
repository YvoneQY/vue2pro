

const install=function (Vue){
    Vue.directive('qy',{

    })
}

export default install






